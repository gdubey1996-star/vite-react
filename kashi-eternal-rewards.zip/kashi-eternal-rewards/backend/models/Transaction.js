const mongoose = require('mongoose');

const TransactionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  phone: { type: String, required: true, index: true },
  type: {
    type: String,
    enum: ['EARN', 'REDEEM', 'WELCOME', 'BONUS', 'EXPIRE', 'ADMIN_CREDIT', 'ADMIN_DEBIT'],
    required: true
  },
  points: { type: Number, required: true },
  balanceAfter: { type: Number, required: true },
  description: { type: String, required: true },
  property: {
    type: String,
    enum: ['Hotel Raghukul Grand', 'Eternal Kashi', 'Basil Leaf', 'Annapurnam Restaurant', 'SYSTEM', 'ADMIN'],
    default: 'SYSTEM'
  },
  amountSpent: { type: Number, default: 0 },
  tierAtTime: { type: String, enum: ['ETERNAL', 'SILVER', 'GOLD', 'PLATINUM'] },
  bonusApplied: { type: Number, default: 0 },
  rewardId: { type: mongoose.Schema.Types.ObjectId, ref: 'Reward' },
  staffId: { type: mongoose.Schema.Types.ObjectId, ref: 'Admin' },
  externalRef: { type: String },
  metadata: { type: Object },
}, {
  timestamps: true,
  // Immutable - no updates allowed
});

// Prevent updates (immutable ledger)
TransactionSchema.pre('findOneAndUpdate', function() {
  throw new Error('Transactions are immutable');
});
TransactionSchema.pre('updateOne', function() {
  throw new Error('Transactions are immutable');
});
TransactionSchema.pre('updateMany', function() {
  throw new Error('Transactions are immutable');
});

TransactionSchema.index({ userId: 1, createdAt: -1 });
TransactionSchema.index({ phone: 1, createdAt: -1 });
TransactionSchema.index({ type: 1, createdAt: -1 });

module.exports = mongoose.model('Transaction', TransactionSchema);
