const mongoose = require('mongoose');

const CampaignSchema = new mongoose.Schema({
  name: { type: String, required: true },
  type: { type: String, enum: ['SMS', 'WHATSAPP', 'PUSH', 'ALL'], required: true },
  message: { type: String, required: true },
  targetTiers: [{ type: String, enum: ['ETERNAL', 'SILVER', 'GOLD', 'PLATINUM'] }],
  targetProperties: [{ type: String }],
  scheduledAt: { type: Date },
  sentAt: { type: Date },
  status: { type: String, enum: ['DRAFT', 'SCHEDULED', 'SENT', 'FAILED'], default: 'DRAFT' },
  recipientCount: { type: Number, default: 0 },
  deliveredCount: { type: Number, default: 0 },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Admin' },
  bonusPoints: { type: Number, default: 0 },
  validTill: { type: Date },
}, { timestamps: true });

module.exports = mongoose.model('Campaign', CampaignSchema);
