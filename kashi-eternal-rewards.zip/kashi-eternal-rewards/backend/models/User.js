const mongoose = require('mongoose');

const TIERS = {
  ETERNAL: { name: 'Eternal', minPoints: 0, bonus: 0, color: '#6B7280' },
  SILVER: { name: 'Silver', minPoints: 5000, bonus: 0.10, color: '#9CA3AF' },
  GOLD: { name: 'Gold', minPoints: 15000, bonus: 0.25, color: '#F59E0B' },
  PLATINUM: { name: 'Platinum', minPoints: 50000, bonus: 0.50, color: '#8B5CF6' },
};

function getTier(points) {
  if (points >= 50000) return 'PLATINUM';
  if (points >= 15000) return 'GOLD';
  if (points >= 5000) return 'SILVER';
  return 'ETERNAL';
}

const UserSchema = new mongoose.Schema({
  phone: { type: String, required: true, unique: true, index: true },
  name: { type: String, default: '' },
  email: { type: String, default: '' },
  dateOfBirth: { type: Date },
  gender: { type: String, enum: ['male', 'female', 'other', ''], default: '' },
  points: { type: Number, default: 100, min: 0 },
  lifetimePoints: { type: Number, default: 100 },
  tier: { type: String, enum: ['ETERNAL', 'SILVER', 'GOLD', 'PLATINUM'], default: 'ETERNAL' },
  isActive: { type: Boolean, default: true },
  isVerified: { type: Boolean, default: false },
  pushSubscription: { type: Object },
  language: { type: String, enum: ['en', 'hi'], default: 'en' },
  lastVisit: { type: Date },
  visitCount: { type: Number, default: 0 },
  totalSpent: { type: Number, default: 0 },
  yearJoined: { type: Number, default: () => new Date().getFullYear() },
  otp: { type: String },
  otpExpiry: { type: Date },
  otpAttempts: { type: Number, default: 0 },
  lastOtpRequest: { type: Date },
}, { timestamps: true });

UserSchema.methods.updateTier = function() {
  const newTier = getTier(this.lifetimePoints);
  this.tier = newTier;
  return newTier;
};

UserSchema.methods.getTierInfo = function() {
  return TIERS[this.tier];
};

UserSchema.methods.getNextTierInfo = function() {
  const tierOrder = ['ETERNAL', 'SILVER', 'GOLD', 'PLATINUM'];
  const currentIdx = tierOrder.indexOf(this.tier);
  if (currentIdx === tierOrder.length - 1) return null;
  const nextTier = tierOrder[currentIdx + 1];
  return { tier: nextTier, ...TIERS[nextTier] };
};

UserSchema.statics.TIERS = TIERS;
UserSchema.statics.getTier = getTier;

module.exports = mongoose.model('User', UserSchema);
