const mongoose = require('mongoose');

const RewardSchema = new mongoose.Schema({
  name: { type: String, required: true },
  nameHindi: { type: String, default: '' },
  description: { type: String, required: true },
  descriptionHindi: { type: String, default: '' },
  pointsRequired: { type: Number, required: true, min: 1 },
  property: {
    type: String,
    enum: ['Hotel Raghukul Grand', 'Eternal Kashi', 'Basil Leaf', 'Annapurnam Restaurant', 'ALL'],
    required: true
  },
  category: {
    type: String,
    enum: ['Dining', 'Stay', 'Experience', 'Festival', 'Spa', 'Other'],
    default: 'Other'
  },
  image: { type: String, default: '' },
  isActive: { type: Boolean, default: true },
  stock: { type: Number, default: -1 }, // -1 = unlimited
  validTill: { type: Date },
  minTier: { type: String, enum: ['ETERNAL', 'SILVER', 'GOLD', 'PLATINUM'], default: 'ETERNAL' },
  termsAndConditions: { type: String, default: '' },
  featured: { type: Boolean, default: false },
  totalRedeemed: { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Reward', RewardSchema);
