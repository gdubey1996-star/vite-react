const express = require('express');
const router = express.Router();
const webpush = require('web-push');
const { adminProtect } = require('../middleware/auth');
const User = require('../models/User');

// POST /api/notifications/push - Send push to all users or filtered
router.post('/push', adminProtect, async (req, res) => {
  try {
    const { title, body, tier, url } = req.body;
    const query = { pushSubscription: { $exists: true, $ne: null } };
    if (tier) query.tier = tier;

    const users = await User.find(query).select('pushSubscription');
    
    let sent = 0, failed = 0;
    const payload = JSON.stringify({ title, body, url: url || '/' });

    for (const user of users) {
      try {
        await webpush.sendNotification(user.pushSubscription, payload);
        sent++;
      } catch (err) {
        failed++;
        if (err.statusCode === 410) {
          // Subscription expired, remove it
          await User.findByIdAndUpdate(user._id, { $unset: { pushSubscription: 1 } });
        }
      }
    }

    res.json({ success: true, message: `Sent: ${sent}, Failed: ${failed}` });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// GET /api/notifications/vapid-key - Get public VAPID key
router.get('/vapid-key', (req, res) => {
  res.json({ publicKey: process.env.VAPID_PUBLIC_KEY });
});

module.exports = router;
