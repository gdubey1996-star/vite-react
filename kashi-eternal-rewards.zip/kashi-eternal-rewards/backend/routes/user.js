const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const { getTierProgress } = require('../utils/points');

// GET /api/user/profile
router.get('/profile', protect, async (req, res) => {
  try {
    const user = req.user;
    const tierProgress = getTierProgress(user.lifetimePoints);
    
    res.json({
      success: true,
      user: {
        id: user._id,
        phone: user.phone,
        name: user.name,
        email: user.email,
        dateOfBirth: user.dateOfBirth,
        gender: user.gender,
        points: user.points,
        lifetimePoints: user.lifetimePoints,
        tier: user.tier,
        tierInfo: user.getTierInfo(),
        nextTier: user.getNextTierInfo(),
        tierProgress,
        visitCount: user.visitCount,
        totalSpent: user.totalSpent,
        lastVisit: user.lastVisit,
        language: user.language,
        yearJoined: user.yearJoined,
        memberSince: user.createdAt,
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch profile' });
  }
});

// PUT /api/user/profile
router.put('/profile', protect, async (req, res) => {
  try {
    const { name, email, dateOfBirth, gender, language } = req.body;
    const user = req.user;

    if (name !== undefined) user.name = name;
    if (email !== undefined) user.email = email;
    if (dateOfBirth !== undefined) user.dateOfBirth = dateOfBirth;
    if (gender !== undefined) user.gender = gender;
    if (language !== undefined) user.language = language;

    await user.save();

    res.json({ success: true, message: 'Profile updated', user: { name: user.name, email: user.email } });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to update profile' });
  }
});

// GET /api/user/transactions
router.get('/transactions', protect, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const transactions = await Transaction.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('rewardId', 'name');

    const total = await Transaction.countDocuments({ userId: req.user._id });

    res.json({
      success: true,
      transactions,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch transactions' });
  }
});

// POST /api/user/push-subscription
router.post('/push-subscription', protect, async (req, res) => {
  try {
    req.user.pushSubscription = req.body.subscription;
    await req.user.save();
    res.json({ success: true, message: 'Push subscription saved' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to save subscription' });
  }
});

// GET /api/user/offers
router.get('/offers', protect, async (req, res) => {
  try {
    const user = req.user;
    const offers = [];

    // Dynamic personalized offers
    if (user.tier === 'ETERNAL') {
      offers.push({
        title: 'Upgrade to Silver!',
        titleHindi: 'सिल्वर बनें!',
        description: `Earn ${5000 - user.lifetimePoints} more points to unlock 10% bonus`,
        type: 'TIER_UPGRADE',
        icon: '⭐'
      });
    }

    // Birthday offer
    if (user.dateOfBirth) {
      const today = new Date();
      const dob = new Date(user.dateOfBirth);
      if (today.getMonth() === dob.getMonth() && today.getDate() === dob.getDate()) {
        offers.push({
          title: 'Happy Birthday! 🎂',
          titleHindi: 'जन्मदिन मुबारक! 🎂',
          description: 'Special 2x points on all transactions today!',
          type: 'BIRTHDAY',
          icon: '🎂',
          multiplier: 2
        });
      }
    }

    // Festival bonus (example: check for Diwali/Holi season)
    const month = new Date().getMonth() + 1;
    if (month === 10 || month === 11) {
      offers.push({
        title: 'Diwali Special! 🪔',
        titleHindi: 'दिवाली स्पेशल! 🪔',
        description: '25% bonus points at all Kashi properties',
        type: 'FESTIVAL',
        icon: '🪔'
      });
    }

    // Low points alert
    if (user.points < 500) {
      offers.push({
        title: 'Earn More Points',
        titleHindi: 'अधिक अंक कमाएं',
        description: 'Visit any Kashi property to earn points on your next stay or dining',
        type: 'EARN_MORE',
        icon: '💎'
      });
    }

    res.json({ success: true, offers });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch offers' });
  }
});

module.exports = router;
