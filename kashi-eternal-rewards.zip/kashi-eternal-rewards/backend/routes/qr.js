const express = require('express');
const router = express.Router();
const { protect, adminProtect } = require('../middleware/auth');
const { generateUserQR, decryptQRPayload } = require('../utils/qr');
const User = require('../models/User');

// GET /api/qr/generate - Generate QR for current user
router.get('/generate', protect, async (req, res) => {
  try {
    const { qrDataURL, payload } = await generateUserQR(req.user._id);
    res.json({
      success: true,
      qrDataURL,
      payload,
      user: {
        name: req.user.name,
        phone: req.user.phone,
        points: req.user.points,
        tier: req.user.tier,
      }
    });
  } catch (error) {
    console.error('QR generate error:', error);
    res.status(500).json({ success: false, message: 'Failed to generate QR code' });
  }
});

// POST /api/qr/scan - Staff scans QR (admin protected)
router.post('/scan', adminProtect, async (req, res) => {
  try {
    const { payload } = req.body;
    
    if (!payload || !payload.startsWith('ker:')) {
      return res.status(400).json({ success: false, message: 'Invalid QR code format' });
    }

    const encryptedData = payload.slice(4); // Remove 'ker:' prefix
    const { userId, ts } = decryptQRPayload(encryptedData);

    // QR should not be older than 24 hours
    if (Date.now() - ts > 24 * 60 * 60 * 1000) {
      return res.status(400).json({ success: false, message: 'QR code expired. User must regenerate.' });
    }

    const user = await User.findById(userId).select('-otp -otpExpiry');
    if (!user || !user.isActive) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        phone: user.phone,
        points: user.points,
        tier: user.tier,
        lifetimePoints: user.lifetimePoints,
      }
    });
  } catch (error) {
    console.error('QR scan error:', error);
    if (error.message === 'Invalid or tampered QR code') {
      return res.status(400).json({ success: false, message: error.message });
    }
    res.status(500).json({ success: false, message: 'QR scan failed' });
  }
});

module.exports = router;
