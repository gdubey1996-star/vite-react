const express = require('express');
const router = express.Router();
const Reward = require('../models/Reward');
const { protect } = require('../middleware/auth');

// GET /api/rewards - Get all active rewards
router.get('/', protect, async (req, res) => {
  try {
    const { category, property, page = 1, limit = 20 } = req.query;
    const query = { isActive: true };
    
    if (category) query.category = category;
    if (property && property !== 'ALL') query.property = { $in: [property, 'ALL'] };
    
    // Filter by user's tier eligibility
    const tierOrder = ['ETERNAL', 'SILVER', 'GOLD', 'PLATINUM'];
    const userTierIdx = tierOrder.indexOf(req.user.tier);
    query.minTier = { $in: tierOrder.slice(0, userTierIdx + 1) };

    const rewards = await Reward.find(query)
      .sort({ featured: -1, pointsRequired: 1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    const total = await Reward.countDocuments(query);

    res.json({
      success: true,
      rewards,
      pagination: { page: parseInt(page), limit: parseInt(limit), total }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch rewards' });
  }
});

// GET /api/rewards/:id
router.get('/:id', protect, async (req, res) => {
  try {
    const reward = await Reward.findById(req.params.id);
    if (!reward) return res.status(404).json({ success: false, message: 'Reward not found' });
    res.json({ success: true, reward });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch reward' });
  }
});

module.exports = router;
