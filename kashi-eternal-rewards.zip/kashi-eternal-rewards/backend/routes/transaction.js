const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const { protect } = require('../middleware/auth');
const { calculatePoints } = require('../utils/points');
const { sendWhatsApp } = require('../utils/otp');

// POS API rate limiter
const posLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  message: { success: false, message: 'Rate limit exceeded' }
});

// POST /api/transaction - POS Integration endpoint
// Supports Rannkly / PetPooja integration
router.post('/', posLimiter, async (req, res) => {
  try {
    const { phone, amount, property, externalRef, staffId } = req.body;
    const apiKey = req.headers['x-api-key'];

    // Validate API key for POS integrations
    if (apiKey !== process.env.POS_API_KEY) {
      return res.status(401).json({ success: false, message: 'Invalid API key' });
    }

    // Validate input
    if (!phone || !amount || !property) {
      return res.status(400).json({ success: false, message: 'phone, amount, and property are required' });
    }

    if (!/^[6-9]\d{9}$/.test(phone)) {
      return res.status(400).json({ success: false, message: 'Invalid phone number' });
    }

    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      return res.status(400).json({ success: false, message: 'Invalid amount' });
    }

    const validProperties = ['Hotel Raghukul Grand', 'Eternal Kashi', 'Basil Leaf', 'Annapurnam Restaurant'];
    if (!validProperties.includes(property)) {
      return res.status(400).json({ success: false, message: 'Invalid property' });
    }

    // Find or create user
    let user = await User.findOne({ phone });
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not registered in loyalty program' });
    }

    // Calculate points with tier bonus
    const { basePoints, bonusPoints, totalPoints } = calculatePoints(amountNum, user.tier);

    if (totalPoints <= 0) {
      return res.status(400).json({ success: false, message: 'Minimum spend ₹100 required to earn points' });
    }

    // Check for duplicate transaction
    if (externalRef) {
      const existing = await Transaction.findOne({ externalRef });
      if (existing) {
        return res.status(409).json({ success: false, message: 'Transaction already processed', transactionId: existing._id });
      }
    }

    // Update user points
    user.points += totalPoints;
    user.lifetimePoints += totalPoints;
    user.totalSpent += amountNum;
    user.lastVisit = new Date();
    user.visitCount += 1;
    
    // Update tier
    const previousTier = user.tier;
    user.updateTier();
    const tierUpgraded = user.tier !== previousTier;

    await user.save();

    // Create transaction record
    const transaction = await Transaction.create({
      userId: user._id,
      phone: user.phone,
      type: 'EARN',
      points: totalPoints,
      balanceAfter: user.points,
      description: `${basePoints} pts earned (₹${amountNum} spent) + ${bonusPoints} ${user.tier} bonus at ${property}`,
      property,
      amountSpent: amountNum,
      tierAtTime: user.tier,
      bonusApplied: bonusPoints,
      externalRef,
    });

    // Send WhatsApp notification
    const msg = `🏨 Kashi Eternal Rewards\nDear ${user.name || 'Guest'}, you earned ${totalPoints} points at ${property}!\nBalance: ${user.points} pts\nTier: ${user.tier}${tierUpgraded ? ` 🎉 Tier upgraded to ${user.tier}!` : ''}`;
    sendWhatsApp(phone, msg).catch(console.error);

    res.json({
      success: true,
      message: `${totalPoints} points added successfully`,
      data: {
        phone,
        pointsEarned: totalPoints,
        basePoints,
        bonusPoints,
        currentBalance: user.points,
        tier: user.tier,
        tierUpgraded,
        transactionId: transaction._id,
      }
    });
  } catch (error) {
    console.error('Transaction error:', error);
    res.status(500).json({ success: false, message: 'Transaction failed' });
  }
});

// POST /api/transaction/redeem - Redeem reward points
router.post('/redeem', protect, async (req, res) => {
  try {
    const { rewardId, staffOtp } = req.body;
    const Reward = require('../models/Reward');
    const user = req.user;

    const reward = await Reward.findById(rewardId);
    if (!reward || !reward.isActive) {
      return res.status(404).json({ success: false, message: 'Reward not found or inactive' });
    }

    // Check tier eligibility
    const tierOrder = ['ETERNAL', 'SILVER', 'GOLD', 'PLATINUM'];
    if (tierOrder.indexOf(user.tier) < tierOrder.indexOf(reward.minTier)) {
      return res.status(403).json({ success: false, message: `This reward requires ${reward.minTier} tier or above` });
    }

    // Check points balance
    if (user.points < reward.pointsRequired) {
      return res.status(400).json({
        success: false,
        message: `Insufficient points. You need ${reward.pointsRequired - user.points} more points.`
      });
    }

    // Check stock
    if (reward.stock !== -1 && reward.stock <= 0) {
      return res.status(400).json({ success: false, message: 'Reward out of stock' });
    }

    // Check validity
    if (reward.validTill && new Date() > reward.validTill) {
      return res.status(400).json({ success: false, message: 'Reward has expired' });
    }

    // Deduct points
    user.points -= reward.pointsRequired;
    await user.save();

    // Update reward stock
    if (reward.stock > 0) {
      reward.stock -= 1;
      reward.totalRedeemed += 1;
      await reward.save();
    } else {
      reward.totalRedeemed += 1;
      await reward.save();
    }

    // Create transaction
    const transaction = await Transaction.create({
      userId: user._id,
      phone: user.phone,
      type: 'REDEEM',
      points: -reward.pointsRequired,
      balanceAfter: user.points,
      description: `Redeemed: ${reward.name}`,
      property: reward.property !== 'ALL' ? reward.property : 'SYSTEM',
      tierAtTime: user.tier,
      rewardId: reward._id,
    });

    res.json({
      success: true,
      message: `Successfully redeemed ${reward.name}!`,
      data: {
        reward: { name: reward.name, description: reward.description },
        pointsDeducted: reward.pointsRequired,
        newBalance: user.points,
        transactionId: transaction._id,
      }
    });
  } catch (error) {
    console.error('Redeem error:', error);
    res.status(500).json({ success: false, message: 'Redemption failed' });
  }
});

module.exports = router;
