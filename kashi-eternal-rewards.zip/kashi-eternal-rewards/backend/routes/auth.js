const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const { generateOTP, sendOTP } = require('../utils/otp');

// OTP rate limiter - max 5 per hour per IP
const otpLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  keyGenerator: (req) => req.body.phone || req.ip,
  message: { success: false, message: 'Too many OTP requests. Please try after 1 hour.' }
});

// Validate Indian phone number
function isValidPhone(phone) {
  return /^[6-9]\d{9}$/.test(phone);
}

// POST /api/auth/send-otp
router.post('/send-otp', otpLimiter, async (req, res) => {
  try {
    const { phone } = req.body;
    
    if (!phone || !isValidPhone(phone)) {
      return res.status(400).json({ success: false, message: 'Enter a valid 10-digit Indian mobile number' });
    }

    // Check if user is blocked (max 3 failed attempts in 15 min)
    let user = await User.findOne({ phone });
    
    if (user && user.otpAttempts >= 3) {
      const blockExpiry = new Date(user.lastOtpRequest.getTime() + 15 * 60 * 1000);
      if (new Date() < blockExpiry) {
        return res.status(429).json({
          success: false,
          message: 'Too many failed attempts. Try again after 15 minutes.'
        });
      } else {
        user.otpAttempts = 0;
      }
    }

    const otp = generateOTP();
    const otpExpiry = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    if (!user) {
      user = new User({ phone, otp, otpExpiry, lastOtpRequest: new Date() });
    } else {
      user.otp = otp;
      user.otpExpiry = otpExpiry;
      user.lastOtpRequest = new Date();
    }
    
    await user.save();

    // Send OTP
    await sendOTP(phone, otp);

    res.json({
      success: true,
      message: 'OTP sent successfully',
      isNewUser: !user.name,
    });
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({ success: false, message: 'Failed to send OTP' });
  }
});

// POST /api/auth/verify-otp
router.post('/verify-otp', async (req, res) => {
  try {
    const { phone, otp } = req.body;

    if (!phone || !otp) {
      return res.status(400).json({ success: false, message: 'Phone and OTP are required' });
    }

    const user = await User.findOne({ phone });
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found. Please request OTP first.' });
    }

    // Check OTP expiry
    if (!user.otpExpiry || new Date() > user.otpExpiry) {
      return res.status(400).json({ success: false, message: 'OTP expired. Please request a new one.' });
    }

    // Validate OTP
    if (user.otp !== otp) {
      user.otpAttempts = (user.otpAttempts || 0) + 1;
      await user.save();
      
      const attemptsLeft = 3 - user.otpAttempts;
      return res.status(400).json({
        success: false,
        message: `Invalid OTP. ${attemptsLeft > 0 ? `${attemptsLeft} attempts remaining.` : 'Account blocked for 15 minutes.'}`
      });
    }

    // OTP verified
    const isNewUser = !user.isVerified;
    user.otp = undefined;
    user.otpExpiry = undefined;
    user.otpAttempts = 0;
    user.isVerified = true;
    user.lastVisit = new Date();
    user.visitCount = (user.visitCount || 0) + 1;

    // Welcome bonus for new users
    if (isNewUser) {
      user.points = 100;
      user.lifetimePoints = 100;
    }

    await user.save();

    // Create welcome transaction for new users
    if (isNewUser) {
      await Transaction.create({
        userId: user._id,
        phone: user.phone,
        type: 'WELCOME',
        points: 100,
        balanceAfter: 100,
        description: 'Welcome bonus - Kashi Eternal Rewards',
        property: 'SYSTEM',
        tierAtTime: 'ETERNAL',
      });
    }

    // Generate JWT (7 days)
    const token = jwt.sign(
      { id: user._id, phone: user.phone },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      message: isNewUser ? 'Welcome to Kashi Eternal Rewards! 🙏 100 bonus points added.' : 'Login successful',
      token,
      isNewUser,
      user: {
        id: user._id,
        phone: user.phone,
        name: user.name,
        points: user.points,
        tier: user.tier,
        lifetimePoints: user.lifetimePoints,
      }
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ success: false, message: 'Verification failed' });
  }
});

// POST /api/auth/admin-login
router.post('/admin-login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const Admin = require('../models/Admin');
    
    const admin = await Admin.findOne({ username, isActive: true });
    if (!admin || !(await admin.comparePassword(password))) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    admin.lastLogin = new Date();
    await admin.save();

    const token = jwt.sign(
      { id: admin._id, username: admin.username, isAdmin: true, role: admin.role },
      process.env.JWT_ADMIN_SECRET || process.env.JWT_SECRET,
      { expiresIn: '8h' }
    );

    res.json({
      success: true,
      token,
      admin: {
        id: admin._id,
        username: admin.username,
        name: admin.name,
        role: admin.role,
        property: admin.property,
      }
    });
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ success: false, message: 'Login failed' });
  }
});

module.exports = router;
