const express = require('express');
const router = express.Router();
const multer = require('multer');
const { parse } = require('csv-parse/sync');
const { adminProtect, superAdmin } = require('../middleware/auth');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const Reward = require('../models/Reward');
const Admin = require('../models/Admin');
const Campaign = require('../models/Campaign');
const { calculatePoints } = require('../utils/points');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

// All routes require admin auth
router.use(adminProtect);

// GET /api/admin/dashboard - Analytics
router.get('/dashboard', async (req, res) => {
  try {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

    const [
      totalUsers,
      activeThisMonth,
      totalTransactions,
      totalPointsIssued,
      totalPointsRedeemed,
      tierDistribution,
      recentTransactions,
      topRedeemers,
    ] = await Promise.all([
      User.countDocuments({ isVerified: true }),
      User.countDocuments({ lastVisit: { $gte: startOfMonth } }),
      Transaction.countDocuments(),
      Transaction.aggregate([
        { $match: { type: { $in: ['EARN', 'WELCOME', 'BONUS'] } } },
        { $group: { _id: null, total: { $sum: '$points' } } }
      ]),
      Transaction.aggregate([
        { $match: { type: 'REDEEM' } },
        { $group: { _id: null, total: { $sum: '$points' } } }
      ]),
      User.aggregate([
        { $match: { isVerified: true } },
        { $group: { _id: '$tier', count: { $sum: 1 } } }
      ]),
      Transaction.find().sort({ createdAt: -1 }).limit(20).populate('userId', 'name phone'),
      User.find({ isVerified: true }).sort({ lifetimePoints: -1 }).limit(10).select('name phone points tier lifetimePoints'),
    ]);

    const monthlyEarned = await Transaction.aggregate([
      { $match: { type: 'EARN', createdAt: { $gte: startOfMonth } } },
      { $group: { _id: null, total: { $sum: '$points' } } }
    ]);

    const propertyStats = await Transaction.aggregate([
      { $match: { type: 'EARN' } },
      { $group: { _id: '$property', totalPoints: { $sum: '$points' }, count: { $sum: 1 }, totalSpent: { $sum: '$amountSpent' } } }
    ]);

    res.json({
      success: true,
      analytics: {
        totalUsers,
        activeThisMonth,
        totalTransactions,
        totalPointsIssued: totalPointsIssued[0]?.total || 0,
        totalPointsRedeemed: Math.abs(totalPointsRedeemed[0]?.total || 0),
        monthlyPointsEarned: monthlyEarned[0]?.total || 0,
        tierDistribution,
        propertyStats,
        recentTransactions,
        topRedeemers,
        repeatVisitRate: totalUsers > 0 ? Math.round((activeThisMonth / totalUsers) * 100) : 0,
      }
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch analytics' });
  }
});

// GET /api/admin/users
router.get('/users', async (req, res) => {
  try {
    const { search, tier, page = 1, limit = 20 } = req.query;
    const query = { isVerified: true };
    
    if (search) query.$or = [{ phone: new RegExp(search, 'i') }, { name: new RegExp(search, 'i') }];
    if (tier) query.tier = tier;

    const users = await User.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .select('-otp -otpExpiry -pushSubscription');

    const total = await User.countDocuments(query);
    res.json({ success: true, users, total });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch users' });
  }
});

// POST /api/admin/users/:id/credit
router.post('/users/:id/credit', async (req, res) => {
  try {
    const { points, reason } = req.body;
    if (!points || !reason) return res.status(400).json({ success: false, message: 'Points and reason required' });

    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    const pointsNum = parseInt(points);
    user.points += pointsNum;
    if (pointsNum > 0) user.lifetimePoints += pointsNum;
    user.updateTier();
    await user.save();

    await Transaction.create({
      userId: user._id,
      phone: user.phone,
      type: pointsNum > 0 ? 'ADMIN_CREDIT' : 'ADMIN_DEBIT',
      points: pointsNum,
      balanceAfter: user.points,
      description: `Admin adjustment: ${reason}`,
      property: 'ADMIN',
      tierAtTime: user.tier,
      staffId: req.admin._id,
    });

    res.json({ success: true, message: 'Points updated', newBalance: user.points });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to update points' });
  }
});

// POST /api/admin/upload-csv - Bulk transaction upload
router.post('/upload-csv', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'CSV file required' });

    const content = req.file.buffer.toString('utf-8');
    const records = parse(content, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    });

    const results = { success: 0, failed: 0, errors: [] };

    for (const record of records) {
      try {
        const { phone, amount, property } = record;
        
        if (!/^[6-9]\d{9}$/.test(phone)) {
          results.failed++;
          results.errors.push(`Invalid phone: ${phone}`);
          continue;
        }

        const user = await User.findOne({ phone });
        if (!user) {
          results.failed++;
          results.errors.push(`User not found: ${phone}`);
          continue;
        }

        const amountNum = parseFloat(amount);
        const { totalPoints, basePoints, bonusPoints } = calculatePoints(amountNum, user.tier);

        user.points += totalPoints;
        user.lifetimePoints += totalPoints;
        user.totalSpent += amountNum;
        user.updateTier();
        await user.save();

        await Transaction.create({
          userId: user._id,
          phone,
          type: 'EARN',
          points: totalPoints,
          balanceAfter: user.points,
          description: `CSV import: ${basePoints} pts + ${bonusPoints} bonus at ${property}`,
          property,
          amountSpent: amountNum,
          tierAtTime: user.tier,
          bonusApplied: bonusPoints,
          staffId: req.admin._id,
        });

        results.success++;
      } catch (err) {
        results.failed++;
        results.errors.push(err.message);
      }
    }

    res.json({ success: true, message: `Processed ${records.length} records`, results });
  } catch (error) {
    console.error('CSV upload error:', error);
    res.status(500).json({ success: false, message: 'CSV processing failed' });
  }
});

// Rewards management
router.get('/rewards', async (req, res) => {
  try {
    const rewards = await Reward.find().sort({ createdAt: -1 });
    res.json({ success: true, rewards });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch rewards' });
  }
});

router.post('/rewards', async (req, res) => {
  try {
    const reward = new Reward(req.body);
    await reward.save();
    res.status(201).json({ success: true, reward });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/rewards/:id', async (req, res) => {
  try {
    const reward = await Reward.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!reward) return res.status(404).json({ success: false, message: 'Reward not found' });
    res.json({ success: true, reward });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/rewards/:id', async (req, res) => {
  try {
    await Reward.findByIdAndUpdate(req.params.id, { isActive: false });
    res.json({ success: true, message: 'Reward deactivated' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// GET /api/admin/transactions
router.get('/transactions', async (req, res) => {
  try {
    const { phone, type, property, page = 1, limit = 50 } = req.query;
    const query = {};
    if (phone) query.phone = new RegExp(phone, 'i');
    if (type) query.type = type;
    if (property) query.property = property;

    const transactions = await Transaction.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .populate('userId', 'name phone tier');

    const total = await Transaction.countDocuments(query);
    res.json({ success: true, transactions, total });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch transactions' });
  }
});

// POST /api/admin/campaigns
router.post('/campaigns', async (req, res) => {
  try {
    const campaign = new Campaign({ ...req.body, createdBy: req.admin._id });
    await campaign.save();
    res.status(201).json({ success: true, campaign });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/campaigns', async (req, res) => {
  try {
    const campaigns = await Campaign.find().sort({ createdAt: -1 }).limit(50);
    res.json({ success: true, campaigns });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch campaigns' });
  }
});

module.exports = router;
