const crypto = require('crypto');
const QRCode = require('qrcode');

const ALGORITHM = 'aes-256-gcm';
const QR_SECRET = process.env.QR_SECRET || 'kashi-eternal-rewards-qr-secret-key-32ch';

function encryptUserId(userId) {
  const key = crypto.scryptSync(QR_SECRET, 'salt', 32);
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  
  const payload = JSON.stringify({ userId: userId.toString(), ts: Date.now() });
  let encrypted = cipher.update(payload, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const tag = cipher.getAuthTag();
  
  return `${iv.toString('hex')}:${tag.toString('hex')}:${encrypted}`;
}

function decryptQRPayload(encryptedData) {
  try {
    const [ivHex, tagHex, encrypted] = encryptedData.split(':');
    const key = crypto.scryptSync(QR_SECRET, 'salt', 32);
    const iv = Buffer.from(ivHex, 'hex');
    const tag = Buffer.from(tagHex, 'hex');
    
    const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(tag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return JSON.parse(decrypted);
  } catch (error) {
    throw new Error('Invalid or tampered QR code');
  }
}

async function generateUserQR(userId) {
  const encrypted = encryptUserId(userId);
  const qrData = `ker:${encrypted}`;
  
  const qrOptions = {
    errorCorrectionLevel: 'H',
    type: 'image/png',
    quality: 0.95,
    margin: 2,
    color: {
      dark: '#78350F', // Saffron brown
      light: '#FFF7ED',
    },
    width: 300,
  };
  
  const qrDataURL = await QRCode.toDataURL(qrData, qrOptions);
  return { qrDataURL, payload: qrData };
}

module.exports = { encryptUserId, decryptQRPayload, generateUserQR };
