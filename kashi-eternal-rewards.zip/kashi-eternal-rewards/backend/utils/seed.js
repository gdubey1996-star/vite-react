require('dotenv').config({ path: '../.env' });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const User = require('../models/User');
const Transaction = require('../models/Transaction');
const Reward = require('../models/Reward');
const Admin = require('../models/Admin');

async function seed() {
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('Connected to MongoDB');

  // Clear collections
  await Promise.all([
    User.deleteMany({}),
    Reward.deleteMany({}),
    Admin.deleteMany({}),
  ]);
  console.log('Cleared collections');

  // Create admin
  const admin = new Admin({
    username: 'admin',
    password: 'KashiAdmin@2024',
    name: 'Kashi Admin',
    email: 'admin@kashieternalrewards.com',
    role: 'SUPER_ADMIN',
    property: 'ALL',
  });
  await admin.save();
  console.log('Admin created: username=admin, password=KashiAdmin@2024');

  // Sample users
  const usersData = [
    { phone: '9876543210', name: 'Ramesh Sharma', points: 12500, lifetimePoints: 15200, tier: 'GOLD', visitCount: 8, totalSpent: 45000 },
    { phone: '9876543211', name: 'Priya Verma', points: 4800, lifetimePoints: 5200, tier: 'SILVER', visitCount: 5, totalSpent: 18000 },
    { phone: '9876543212', name: 'Ankit Singh', points: 800, lifetimePoints: 1200, tier: 'ETERNAL', visitCount: 2, totalSpent: 5000 },
    { phone: '9876543213', name: 'Sunita Devi', points: 52000, lifetimePoints: 58000, tier: 'PLATINUM', visitCount: 25, totalSpent: 180000 },
    { phone: '9876543214', name: 'Vikram Gupta', points: 2300, lifetimePoints: 3100, tier: 'ETERNAL', visitCount: 3, totalSpent: 12000 },
  ];

  const createdUsers = [];
  for (const u of usersData) {
    const user = new User({ ...u, isVerified: true, lastVisit: new Date() });
    await user.save();
    createdUsers.push(user);
  }
  console.log(`Created ${createdUsers.length} test users`);

  // Sample transactions
  const properties = ['Hotel Raghukul Grand', 'Eternal Kashi', 'Basil Leaf', 'Annapurnam Restaurant'];
  for (const user of createdUsers) {
    const txCount = Math.floor(Math.random() * 5) + 2;
    let balance = 100;
    
    await Transaction.create({
      userId: user._id, phone: user.phone, type: 'WELCOME',
      points: 100, balanceAfter: 100, description: 'Welcome bonus',
      property: 'SYSTEM', tierAtTime: 'ETERNAL',
    });

    for (let i = 0; i < txCount; i++) {
      const amount = (Math.floor(Math.random() * 50) + 5) * 100;
      const points = Math.floor(amount / 100) * 10;
      balance += points;
      await Transaction.create({
        userId: user._id, phone: user.phone, type: 'EARN',
        points, balanceAfter: balance,
        description: `${points} pts earned (₹${amount} spent) at ${properties[i % 4]}`,
        property: properties[i % 4], amountSpent: amount, tierAtTime: user.tier,
        createdAt: new Date(Date.now() - (txCount - i) * 7 * 24 * 60 * 60 * 1000),
      });
    }
  }
  console.log('Created sample transactions');

  // Rewards catalog
  const rewards = [
    {
      name: 'Basil Leaf Satvik Thali for 2',
      nameHindi: 'बेसिल लीफ सात्विक थाली (2 लोगों के लिए)',
      description: 'Complimentary traditional Satvik Thali for two at Basil Leaf restaurant',
      descriptionHindi: 'बेसिल लीफ में दो लोगों के लिए निःशुल्क सात्विक थाली',
      pointsRequired: 2000,
      property: 'Basil Leaf',
      category: 'Dining',
      featured: true,
      minTier: 'ETERNAL',
    },
    {
      name: 'Rooftop Ganga Dinner for 2',
      nameHindi: 'गंगा रूफटॉप डिनर (2 लोगों के लिए)',
      description: 'Romantic rooftop dinner with Ganga view at Eternal Kashi',
      descriptionHindi: 'ईटर्नल काशी में गंगा दर्शन के साथ रोमांटिक रूफटॉप डिनर',
      pointsRequired: 5000,
      property: 'Eternal Kashi',
      category: 'Dining',
      featured: true,
      minTier: 'ETERNAL',
    },
    {
      name: 'Hotel Raghukul Grand Standard Night',
      nameHindi: 'होटल रघुकुल ग्रैंड स्टैंडर्ड रात्रि',
      description: 'One complimentary night stay at Hotel Raghukul Grand (Standard Room)',
      descriptionHindi: 'होटल रघुकुल ग्रैंड में एक निःशुल्क रात्रि प्रवास (स्टैंडर्ड रूम)',
      pointsRequired: 10000,
      property: 'Hotel Raghukul Grand',
      category: 'Stay',
      minTier: 'SILVER',
    },
    {
      name: 'Ganga Aarti Festival Pass',
      nameHindi: 'गंगा आरती फेस्टिवल पास',
      description: 'VIP access to Ganga Aarti with guided cultural experience',
      descriptionHindi: 'गाइडेड सांस्कृतिक अनुभव के साथ गंगा आरती में VIP प्रवेश',
      pointsRequired: 3000,
      property: 'ALL',
      category: 'Experience',
      featured: true,
      minTier: 'ETERNAL',
    },
    {
      name: 'Annapurnam Special Thali',
      nameHindi: 'अन्नपूर्णम स्पेशल थाली',
      description: 'Traditional Kashi special thali with desserts at Annapurnam',
      descriptionHindi: 'अन्नपूर्णम में मिठाई के साथ पारंपरिक काशी स्पेशल थाली',
      pointsRequired: 1500,
      property: 'Annapurnam Restaurant',
      category: 'Dining',
      minTier: 'ETERNAL',
    },
    {
      name: 'Hotel Raghukul Suite Upgrade',
      nameHindi: 'रघुकुल ग्रैंड सुइट अपग्रेड',
      description: 'Complimentary suite upgrade for 2 nights at Hotel Raghukul Grand',
      descriptionHindi: 'होटल रघुकुल ग्रैंड में 2 रातों के लिए निःशुल्क सुइट अपग्रेड',
      pointsRequired: 25000,
      property: 'Hotel Raghukul Grand',
      category: 'Stay',
      minTier: 'GOLD',
    },
  ];

  await Reward.insertMany(rewards);
  console.log(`Created ${rewards.length} rewards`);

  console.log('\n✅ Seed completed!');
  console.log('\n📱 Test phone numbers:');
  usersData.forEach(u => console.log(`   ${u.phone} - ${u.name} (${u.tier})`));
  console.log('\n🔐 Admin credentials:');
  console.log('   Username: admin');
  console.log('   Password: KashiAdmin@2024');
  
  await mongoose.disconnect();
}

seed().catch(console.error);
