const crypto = require('crypto');

// Generate 6-digit OTP
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Send OTP via MSG91
async function sendOTPviaMSG91(phone, otp) {
  const axios = require('axios');
  const authKey = process.env.MSG91_AUTH_KEY;
  const templateId = process.env.MSG91_TEMPLATE_ID;
  
  if (!authKey) throw new Error('MSG91_AUTH_KEY not configured');

  const payload = {
    template_id: templateId,
    mobile: `91${phone}`,
    authkey: authKey,
    otp: otp,
  };

  const response = await axios.post('https://api.msg91.com/api/v5/otp', payload, {
    headers: { 'Content-Type': 'application/json' }
  });
  
  return response.data;
}

// Send OTP via Twilio
async function sendOTPviaTwilio(phone, otp) {
  const twilio = require('twilio');
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  
  const message = await client.messages.create({
    body: `Your Kashi Eternal Rewards OTP is ${otp}. Valid for 5 minutes. Do not share with anyone.`,
    from: process.env.TWILIO_PHONE_NUMBER,
    to: `+91${phone}`
  });
  
  return message;
}

// Mock OTP for development
async function sendOTPMock(phone, otp) {
  console.log(`📱 [DEV] OTP for ${phone}: ${otp}`);
  return { success: true, dev: true };
}

async function sendOTP(phone, otp) {
  const provider = process.env.SMS_PROVIDER || 'MOCK';
  
  try {
    if (provider === 'MSG91') {
      return await sendOTPviaMSG91(phone, otp);
    } else if (provider === 'TWILIO') {
      return await sendOTPviaTwilio(phone, otp);
    } else {
      return await sendOTPMock(phone, otp);
    }
  } catch (error) {
    console.error('OTP send error:', error.message);
    // Fallback to mock in dev
    if (process.env.NODE_ENV !== 'production') {
      return await sendOTPMock(phone, otp);
    }
    throw error;
  }
}

// Send WhatsApp notification via WhatsApp Cloud API
async function sendWhatsApp(phone, message) {
  const axios = require('axios');
  const token = process.env.WHATSAPP_TOKEN;
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  
  if (!token || !phoneNumberId) {
    console.log(`📱 [DEV] WhatsApp to ${phone}: ${message}`);
    return;
  }

  await axios.post(
    `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`,
    {
      messaging_product: 'whatsapp',
      to: `91${phone}`,
      type: 'text',
      text: { body: message }
    },
    {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    }
  );
}

module.exports = { generateOTP, sendOTP, sendWhatsApp };
