const User = require('../models/User');

const POINTS_PER_100 = 10; // 10 points per ₹100

function calculatePoints(amountSpent, tier) {
  const basePoints = Math.floor(amountSpent / 100) * POINTS_PER_100;
  const tierBonuses = { ETERNAL: 0, SILVER: 0.10, GOLD: 0.25, PLATINUM: 0.50 };
  const bonus = tierBonuses[tier] || 0;
  const bonusPoints = Math.floor(basePoints * bonus);
  return { basePoints, bonusPoints, totalPoints: basePoints + bonusPoints };
}

function getNextTier(lifetimePoints) {
  if (lifetimePoints >= 50000) return null;
  if (lifetimePoints >= 15000) return { tier: 'PLATINUM', pointsNeeded: 50000 - lifetimePoints };
  if (lifetimePoints >= 5000) return { tier: 'GOLD', pointsNeeded: 15000 - lifetimePoints };
  return { tier: 'SILVER', pointsNeeded: 5000 - lifetimePoints };
}

function getTierProgress(lifetimePoints) {
  const tiers = [
    { name: 'ETERNAL', min: 0, max: 5000 },
    { name: 'SILVER', min: 5000, max: 15000 },
    { name: 'GOLD', min: 15000, max: 50000 },
    { name: 'PLATINUM', min: 50000, max: 50000 },
  ];
  
  const current = User.getTier(lifetimePoints);
  if (current === 'PLATINUM') return { progress: 100, tier: 'PLATINUM' };
  
  const tierInfo = tiers.find(t => t.name === current);
  const progress = Math.min(100, Math.floor(
    ((lifetimePoints - tierInfo.min) / (tierInfo.max - tierInfo.min)) * 100
  ));
  
  return { progress, tier: current, min: tierInfo.min, max: tierInfo.max };
}

module.exports = { calculatePoints, getNextTier, getTierProgress, POINTS_PER_100 };
