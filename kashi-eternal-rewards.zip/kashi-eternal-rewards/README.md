# 🪔 Kashi Eternal Rewards - Deployment Guide

## 24-Hour Launch Checklist

---

## 📁 Project Structure
```
kashi-eternal-rewards/
├── frontend/              # React + Vite PWA → Deploy to Vercel
│   ├── src/
│   │   ├── pages/         # LoginPage, Dashboard, Rewards, QR, Transactions, Profile, Admin
│   │   ├── components/    # Layout, TierProgressRing
│   │   ├── context/       # AuthContext, LangContext (EN/HI)
│   │   └── utils/         # api.js (axios)
│   └── vite.config.js     # PWA enabled
├── backend/               # Node.js + Express → Deploy to Render
│   ├── models/            # User, Transaction (immutable), Reward, Admin, Campaign
│   ├── routes/            # auth, user, transaction, rewards, qr, admin, notifications
│   ├── middleware/        # auth.js (JWT)
│   └── utils/             # otp.js, qr.js, points.js, seed.js
└── qr-table-tent-printable.html   # Print for restaurant tables
```

---

## 🚀 STEP 1: MongoDB Atlas Setup (10 min)

1. Go to [mongodb.com/cloud/atlas](https://mongodb.com/cloud/atlas)
2. Create free account → Create Free Cluster (M0)
3. Database Access → Add User: `kashiapp` / strong password
4. Network Access → Add IP: `0.0.0.0/0` (allow all for Render)
5. Get connection string: `mongodb+srv://kashiapp:<password>@cluster0.xxxxx.mongodb.net/kashi-eternal-rewards`

---

## 🚀 STEP 2: Backend → Render (15 min)

1. Go to [render.com](https://render.com) → Sign up free
2. New → Web Service → Connect GitHub repo
3. Settings:
   - **Name**: `kashi-eternal-rewards-api`
   - **Root Directory**: `backend`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free
4. Environment Variables (add all from backend/.env.example):

```
NODE_ENV=production
MONGODB_URI=mongodb+srv://...
JWT_SECRET=<generate 64 char random string>
JWT_ADMIN_SECRET=<another 64 char random>
QR_SECRET=<32 char random>
ALLOWED_ORIGINS=https://your-frontend.vercel.app
POS_API_KEY=<your-pos-api-key>
SMS_PROVIDER=MOCK  # Change to MSG91 or TWILIO for production
```

5. Deploy → Copy your Render URL: `https://kashi-eternal-rewards-api.onrender.com`

### Generate VAPID keys for push notifications:
```bash
npm install -g web-push
web-push generate-vapid-keys
# Add VAPID_PUBLIC_KEY and VAPID_PRIVATE_KEY to Render env vars
```

### Seed the database (run once):
```bash
cd backend
npm install
# Set MONGODB_URI in your local .env
node utils/seed.js
```

**This creates:**
- Admin: username=`admin`, password=`KashiAdmin@2024`
- 5 test users (phones: 9876543210 to 9876543214)
- 6 rewards
- Sample transactions

---

## 🚀 STEP 3: Frontend → Vercel (10 min)

1. Go to [vercel.com](https://vercel.com) → Import Git repo
2. **Root Directory**: `frontend`
3. **Framework Preset**: Vite
4. **Build Command**: `npm run build`
5. **Output Directory**: `dist`
6. Environment Variables:
   ```
   VITE_API_URL=https://kashi-eternal-rewards-api.onrender.com/api
   ```
7. Deploy → Your app is live!

### One-click deploy links:

[![Deploy Frontend to Vercel](https://vercel.com/button)](https://vercel.com/new)
[![Deploy Backend to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

---

## 🔑 Post-Deployment Config

### MSG91 SMS (Recommended for India - production):
1. Sign up at [msg91.com](https://msg91.com)
2. Create OTP template: "Your Kashi Eternal Rewards OTP is ##OTP##. Valid 5 minutes."
3. Add to Render env:
   ```
   SMS_PROVIDER=MSG91
   MSG91_AUTH_KEY=your-key
   MSG91_TEMPLATE_ID=your-template-id
   ```

### WhatsApp Cloud API (Optional):
1. Create Meta developer account
2. Set up WhatsApp Business API
3. Add `WHATSAPP_TOKEN` and `WHATSAPP_PHONE_NUMBER_ID` to Render

### POS Integration (Rannkly/PetPooja):
```
POST https://kashi-eternal-rewards-api.onrender.com/api/transaction
Headers: x-api-key: YOUR_POS_API_KEY
Body: { "phone": "9876543210", "amount": 1500, "property": "Basil Leaf" }
```

---

## 📱 PWA Installation
Users visiting on mobile will see "Add to Home Screen" prompt automatically.
No app store required!

---

## 🧪 Test Credentials

| Phone | Name | Tier | Points |
|-------|------|------|--------|
| 9876543210 | Ramesh Sharma | GOLD | 12,500 |
| 9876543211 | Priya Verma | SILVER | 4,800 |
| 9876543212 | Ankit Singh | ETERNAL | 800 |
| 9876543213 | Sunita Devi | PLATINUM | 52,000 |
| 9876543214 | Vikram Gupta | ETERNAL | 2,300 |

**Dev mode OTP**: Check Render logs for OTP (printed to console when SMS_PROVIDER=MOCK)

**Admin Panel**: `/admin` → username: `admin`, password: `KashiAdmin@2024`

---

## 🔐 Security Checklist
- [x] JWT expiry (7 days user, 8h admin)
- [x] Helmet middleware
- [x] Rate limiting (OTP: 5/hour, API: 200/15min, POS: 60/min)
- [x] CORS whitelist
- [x] Input validation (phone regex, amount validation)
- [x] Encrypted QR payload (AES-256-GCM)
- [x] Immutable transaction ledger
- [x] OTP: 5min expiry, max 3 attempts, 15min lockout
- [x] HTTPS enforced (Vercel + Render)
- [x] MongoDB sanitization

---

## 📊 Scaling to 10,000 Users

When ready to scale:
1. **MongoDB**: Upgrade to M10 dedicated cluster
2. **Render**: Upgrade to Standard plan (no sleep)
3. **Redis**: Add caching for leaderboard/analytics
4. **CDN**: Vercel handles frontend CDN automatically
5. **Queue**: Add Bull/BullMQ for bulk notifications

---

## 🎨 Customization

### Change OTP provider:
- Set `SMS_PROVIDER=MSG91` or `SMS_PROVIDER=TWILIO` in Render

### Add properties:
Update `validProperties` array in `backend/routes/transaction.js` and related models

### Change points rate:
Update `POINTS_PER_100` in `backend/utils/points.js`

### Change tier thresholds:
Update `TIERS` object in `backend/models/User.js`

---

## 📞 Support

- Frontend URL: `https://your-app.vercel.app`
- Admin Panel: `https://your-app.vercel.app/admin`
- API Health: `https://your-api.onrender.com/health`
- API Docs: See route files in `/backend/routes/`

---

🪔 **Har Har Mahadev** · Kashi Eternal Rewards v1.0
