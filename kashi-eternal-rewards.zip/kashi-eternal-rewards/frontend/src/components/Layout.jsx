import { Link, useLocation } from 'react-router-dom';
import { useLang } from '../context/LangContext';

const NavIcon = ({ icon, label, to, active }) => (
  <Link to={to} className={`bottom-nav-item ${active ? 'active' : ''}`}>
    <span className="text-2xl leading-none">{icon}</span>
    <span>{label}</span>
  </Link>
);

export default function Layout({ children, title, showBack, onBack }) {
  const location = useLocation();
  const { t, toggleLang, lang } = useLang();
  const path = location.pathname;

  return (
    <div className="min-h-screen mandir-bg pb-24">
      {/* Top App Bar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-saffron-100 safe-top">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            {showBack ? (
              <button onClick={onBack} className="text-saffron-700 text-xl mr-1">←</button>
            ) : (
              <span className="text-xl">🪔</span>
            )}
            <h1 className="font-display font-semibold text-saffron-900 text-lg leading-tight">
              {title || t.appName}
            </h1>
          </div>
          <button
            onClick={toggleLang}
            className="text-xs text-saffron-700 border border-saffron-200 px-2.5 py-1 rounded-full font-medium"
          >
            {t.language}
          </button>
        </div>
      </header>

      {/* Content */}
      <main className="px-4 py-4 max-w-lg mx-auto">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="bottom-nav">
        <NavIcon icon="🏠" label={t.dashboard} to="/" active={path === '/'} />
        <NavIcon icon="🎁" label={t.rewards} to="/rewards" active={path === '/rewards'} />
        <NavIcon icon="📲" label={t.qrCode} to="/qr" active={path === '/qr'} />
        <NavIcon icon="📋" label={t.transactions} to="/transactions" active={path === '/transactions'} />
        <NavIcon icon="👤" label={t.profile} to="/profile" active={path === '/profile'} />
      </nav>
    </div>
  );
}
