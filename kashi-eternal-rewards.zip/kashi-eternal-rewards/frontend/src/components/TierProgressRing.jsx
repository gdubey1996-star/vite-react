export default function TierProgressRing({ progress = 0, tier = 'ETERNAL', size = 140 }) {
  const radius = (size - 20) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  const tierColors = {
    ETERNAL: { stroke: '#6B7280', text: '#6B7280', bg: '#F3F4F6', emoji: '⚡' },
    SILVER: { stroke: '#9CA3AF', text: '#6B7280', bg: '#F9FAFB', emoji: '⭐' },
    GOLD: { stroke: '#F59E0B', text: '#D97706', bg: '#FFFBEB', emoji: '🌟' },
    PLATINUM: { stroke: '#8B5CF6', text: '#7C3AED', bg: '#F5F3FF', emoji: '💎' },
  };

  const colors = tierColors[tier] || tierColors.ETERNAL;

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="progress-ring">
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#F3F4F6"
            strokeWidth="10"
          />
          {/* Progress circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={colors.stroke}
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className="progress-ring__circle"
          />
        </svg>

        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl">{colors.emoji}</span>
          <span className="text-xs font-semibold mt-0.5" style={{ color: colors.text }}>
            {progress}%
          </span>
        </div>
      </div>
    </div>
  );
}
