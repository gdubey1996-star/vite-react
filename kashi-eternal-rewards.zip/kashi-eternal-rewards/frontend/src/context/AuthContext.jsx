import { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('ker_token');
    const savedUser = localStorage.getItem('ker_user');
    
    if (token && savedUser) {
      try {
        setUser(JSON.parse(savedUser));
        fetchProfile(); // Refresh from server
      } catch {
        logout();
      }
    }
    setLoading(false);
  }, []);

  const fetchProfile = async () => {
    try {
      const { data } = await api.get('/user/profile');
      if (data.success) {
        setUser(data.user);
        localStorage.setItem('ker_user', JSON.stringify(data.user));
      }
    } catch {
      // Token might be expired - let interceptor handle
    }
  };

  const login = (token, userData) => {
    localStorage.setItem('ker_token', token);
    localStorage.setItem('ker_user', JSON.stringify(userData));
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('ker_token');
    localStorage.removeItem('ker_user');
    setUser(null);
  };

  const updateUser = (updates) => {
    const updated = { ...user, ...updates };
    setUser(updated);
    localStorage.setItem('ker_user', JSON.stringify(updated));
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, fetchProfile, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
