import { createContext, useContext, useState } from 'react';

const translations = {
  en: {
    appName: 'Kashi Eternal Rewards',
    login: 'Login',
    logout: 'Logout',
    dashboard: 'Dashboard',
    rewards: 'Rewards',
    transactions: 'Transactions',
    qrCode: 'My QR',
    profile: 'Profile',
    points: 'Points',
    myPoints: 'My Points',
    tier: 'Tier',
    welcomeBack: 'Welcome back',
    enterPhone: 'Enter your mobile number',
    sendOtp: 'Send OTP',
    verifyOtp: 'Verify OTP',
    otpSent: 'OTP sent to',
    resendOtp: 'Resend OTP',
    verifying: 'Verifying...',
    sending: 'Sending...',
    redeemNow: 'Redeem Now',
    pointsRequired: 'Points Required',
    yourBalance: 'Your Balance',
    earnPoints: 'Earn Points',
    tierProgress: 'Tier Progress',
    recentTransactions: 'Recent Transactions',
    noTransactions: 'No transactions yet',
    earned: 'Earned',
    redeemed: 'Redeemed',
    welcome: 'Welcome Bonus',
    showQrAtCounter: 'Show this QR at the hotel counter',
    scanToEarn: 'Scan to earn & redeem points',
    properties: {
      'Hotel Raghukul Grand': 'Hotel Raghukul Grand',
      'Eternal Kashi': 'Eternal Kashi',
      'Basil Leaf': 'Basil Leaf',
      'Annapurnam Restaurant': 'Annapurnam Restaurant',
    },
    tiers: { ETERNAL: 'Eternal', SILVER: 'Silver', GOLD: 'Gold', PLATINUM: 'Platinum' },
    categories: { Dining: 'Dining', Stay: 'Stay', Experience: 'Experience', Festival: 'Festival' },
    insufficientPoints: 'Insufficient points',
    redeemSuccess: 'Redeemed successfully!',
    error: 'Something went wrong',
    loading: 'Loading...',
    language: 'हिंदी',
    name: 'Full Name',
    email: 'Email',
    saveProfile: 'Save Profile',
    memberSince: 'Member since',
    totalVisits: 'Total Visits',
    totalSpent: 'Total Spent',
  },
  hi: {
    appName: 'काशी इटर्नल रिवार्ड्स',
    login: 'लॉगिन',
    logout: 'लॉगआउट',
    dashboard: 'डैशबोर्ड',
    rewards: 'रिवार्ड्स',
    transactions: 'लेनदेन',
    qrCode: 'मेरा QR',
    profile: 'प्रोफ़ाइल',
    points: 'अंक',
    myPoints: 'मेरे अंक',
    tier: 'टीयर',
    welcomeBack: 'स्वागत है',
    enterPhone: 'अपना मोबाइल नंबर दर्ज करें',
    sendOtp: 'OTP भेजें',
    verifyOtp: 'OTP सत्यापित करें',
    otpSent: 'OTP भेजा गया',
    resendOtp: 'OTP दोबारा भेजें',
    verifying: 'सत्यापित हो रहा है...',
    sending: 'भेजा जा रहा है...',
    redeemNow: 'अभी रिडीम करें',
    pointsRequired: 'आवश्यक अंक',
    yourBalance: 'आपका बैलेंस',
    earnPoints: 'अंक कमाएं',
    tierProgress: 'टीयर प्रगति',
    recentTransactions: 'हाल के लेनदेन',
    noTransactions: 'अभी कोई लेनदेन नहीं',
    earned: 'कमाए',
    redeemed: 'रिडीम किए',
    welcome: 'स्वागत बोनस',
    showQrAtCounter: 'होटल काउंटर पर यह QR दिखाएं',
    scanToEarn: 'अंक कमाने और रिडीम करने के लिए स्कैन करें',
    properties: {
      'Hotel Raghukul Grand': 'होटल रघुकुल ग्रैंड',
      'Eternal Kashi': 'ईटर्नल काशी',
      'Basil Leaf': 'बेसिल लीफ',
      'Annapurnam Restaurant': 'अन्नपूर्णम रेस्तरां',
    },
    tiers: { ETERNAL: 'इटर्नल', SILVER: 'सिल्वर', GOLD: 'गोल्ड', PLATINUM: 'प्लैटिनम' },
    categories: { Dining: 'भोजन', Stay: 'प्रवास', Experience: 'अनुभव', Festival: 'त्योहार' },
    insufficientPoints: 'अपर्याप्त अंक',
    redeemSuccess: 'सफलतापूर्वक रिडीम किया!',
    error: 'कुछ गलत हुआ',
    loading: 'लोड हो रहा है...',
    language: 'English',
    name: 'पूरा नाम',
    email: 'ईमेल',
    saveProfile: 'प्रोफ़ाइल सहेजें',
    memberSince: 'सदस्य बने',
    totalVisits: 'कुल भेंट',
    totalSpent: 'कुल खर्च',
  }
};

const LangContext = createContext();

export function LangProvider({ children }) {
  const [lang, setLang] = useState(localStorage.getItem('ker_lang') || 'en');
  
  const toggleLang = () => {
    const newLang = lang === 'en' ? 'hi' : 'en';
    setLang(newLang);
    localStorage.setItem('ker_lang', newLang);
  };
  
  const t = translations[lang];
  
  return (
    <LangContext.Provider value={{ lang, toggleLang, t }}>
      {children}
    </LangContext.Provider>
  );
}

export const useLang = () => useContext(LangContext);
